/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatlabserver;

import java.io.BufferedReader; // Importare la classe BufferedReader
import java.io.IOException; // Importare la classe IOException
import java.io.InputStreamReader; // Importare la classe InputStreamReader
import java.io.PrintWriter; // Importare la classe PrintWriter
import java.net.Socket; // Importare la classe Socket
import java.util.ArrayList; // Importare la classe ArrayList
import java.util.Arrays; // Importare la classe Arrays
import static javax.swing.JOptionPane.showMessageDialog; // Importare il metodo statico showMessageDialog dalla classe JOptionPane
import static javax.swing.JOptionPane.INFORMATION_MESSAGE; // Importare la costante INFORMATION_MESSAGE dalla classe JOptionPane

/**
 *
 * @author 39327
 */
public class ClientHandler extends Thread {
    
    // Dichiarazione attributi
    private final ServerFrame interfacciaGrafica;
    private final Socket clientSocket;
    private String nickname;

    // Dichiarazione attributi statici
    public static ArrayList<ClientHandler> listaClient = new ArrayList<>();

    // Metodi costruttori
    public ClientHandler(ServerFrame interfacciaGrafica, Socket clientSocket) {
        this.interfacciaGrafica = interfacciaGrafica;
        this.clientSocket = clientSocket;
        nickname = "";
    }

    // Metodi getter
    public Socket getClientSocket() {
        return clientSocket;
    }
    public String getNickname() {
        return nickname;
    }
    // Metodo getter finalizzato a restituire il valore di nickname di tutti i client connessi alla rete di comunicazione
    public String[] getListaClientNickname() {

        // Dichiarazione ed implementazione array (locali)
        String[] listaClientNickname = new String[listaClient.size()];

        // Dichiarazione oggetti (locali)
        ClientHandler client;

        // Caricamento dell'array listaClientNickname
        for (int i = 0; i < listaClient.size(); i++) {
            client = listaClient.get(i);
            listaClientNickname[i] = client.getNickname();
        }

        // Restituzione dell'array listaClientNickname
        return listaClientNickname;
    }

    // Altri metodi
    // Per eseguire un thread
    @Override
    public void run() {

        // Dichiarazione (ed implementazione) variabili (locali)
        int i = 0;
        boolean isEsistente;
        String messaggioClient, nicknameDestinatario, corpoMessaggio;

        // Dichiarazione array (locali)
        String[] messaggioClientFrammenti;

        // Dichiarazione oggetti (locali)
        BufferedReader messaggioClientIn;
        PrintWriter messaggioServerOut;

        try {

            // Dichiarazione ed implementazione oggetti (locali)
            ClientHandler client;

            // Implementazione oggetti necessari allo scambio di informazioni (stream) client-server
            messaggioClientIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);

            // Richiesta di autenticazione da parte del server per il client connesso
            do {

                // Resettare il valore di isEsistente su false
                isEsistente = false;

                // Lettura del messaggio ricevuto
                messaggioClient = messaggioClientIn.readLine();
                
                // Stampa del messaggio ricevuto
                interfacciaGrafica.setAreaOutputServer("\nNuovo Utente: " + messaggioClient);
                
                // Se il messaggio ricevuto contiene "NICK "
                if (messaggioClient.contains("NICK ")) {

                    // Frammentazione di messaggioClient in due frammenti, dei quali si utilizza l'ultimo: nickname
                    messaggioClientFrammenti = messaggioClient.split(" ", 2);

                    // Estrazione del nickname
                    nickname = messaggioClientFrammenti[1];

                    // Verifica dell'esistenza del nuovo client
                    while (!isEsistente && i < listaClient.size()) {
                        client = listaClient.get(i);
                        if (client.getNickname().equals(nickname))
                            isEsistente = true;
                        i++;
                    }

                    // Se il nuovo client esiste già
                    if (isEsistente) {

                        // Inviare un messaggio di errore
                        messaggioServerOut.println("App: Attenzione! Utente già esistente.");
                    }
                
                // Altrimenti
                } else {
                    
                    // Inviare un messaggio di errore
                    messaggioServerOut.println("App: Attenzione! Seguire la seguente sintassi: NICK <Nickname>!");
                }    
            } while (!messaggioClient.contains("NICK ") || isEsistente);

            // Aggiunta del nuovo client alla lista di client connessi alla rete di comunicazione
            listaClient.add(this);

            // Messaggio di segnalazione di autenticazione avvenuta con successo indirizzato al nuovo client autenticato
            messaggioServerOut.println("App: Ok! Benvenuto " + nickname + '!');

            // Messaggio di segnalazione di autenticazione avvenuta con successo indirizzato a tutti gli altri client della rete di comunicazione
            for (ClientHandler c : listaClient) {
                if (!c.getNickname().equals(nickname)) {
                    messaggioServerOut = new PrintWriter(c.getClientSocket().getOutputStream(), true);
                    messaggioServerOut.println("App: " + nickname + " ha effettuato l'accesso.");
                }
            }

            // Riconnessione al nuovo client autenticato
            messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);

            // Comunicazione client-server
            do {

                // Lettura del messaggio ricevuto
                messaggioClient = messaggioClientIn.readLine();

                // Stampa del messaggio ricevuto
                interfacciaGrafica.setAreaOutputServer('\n' + nickname + ": " + messaggioClient);

                // Comunicazione Unicast
                if (messaggioClient.contains("CHAT ")) {

                    // Implementazione variabili (locali)
                    i = 0;
                    isEsistente = false;

                    // Implementazione oggetti (locali)
                    client = null;

                    // Frammentazione di messaggioClient in due frammenti, dei quali si utilizza l'ultimo: nicknameDestinatario
                    messaggioClientFrammenti = messaggioClient.split(" ", 2);

                    // Assegnazione dei frammenti alle relative locazioni di memoria
                    nicknameDestinatario = messaggioClientFrammenti[1];

                    // Verifica dell'esistenza del client destinatario
                    while (!isEsistente && i < listaClient.size()) {
                        client = listaClient.get(i);
                        if (client.getNickname().equals(nicknameDestinatario))
                            isEsistente = true;
                        i++;
                    }

                    // Se il client destinatario esiste
                    if (isEsistente) {

                        // Se il client con il quale si vuole comunicare coincide con se stessi
                        if (this.getNickname().equals(client.getNickname())) {

                            // Inviare un messaggio di errore
                            messaggioServerOut.println("App: Attenzione! Non è consentito comunicare con se stessi!");

                        // Altrimenti
                        } else {

                            // Avviare la comunicazione Unicast
                            messaggioServerOut.println("App: Comunicazione con " + nicknameDestinatario + " abilitata!");
                            do {
                                messaggioClient = messaggioClientIn.readLine();
                                if (!messaggioClient.equals("STOP")) {
                                    messaggioServerOut = new PrintWriter(client.getClientSocket().getOutputStream(), true);
                                    messaggioServerOut.println(nickname + ": " + messaggioClient);
                                    messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);
                                    messaggioServerOut.println("App: Messaggio inviato!");
                                }
                            } while (!messaggioClient.equals("STOP"));

                            // Messaggio di avvenuta terminazione della comunicazione Unicast
                            messaggioServerOut.println("App: Comunicazione con " + nicknameDestinatario + " disabilitata!");
                        }

                    // Altrimenti
                    } else {

                        // Inviare un messaggio di errore
                        messaggioServerOut.println("App: Attenzione! Utente inesistente.");
                    }

                // Comunicazione Broadcast
                } else if (messaggioClient.contains("BROADCAST ")) {

                    // Frammentazione di messaggioClient in due frammenti, dei quali si utilizza l'ultimo: corpoMessaggio
                    messaggioClientFrammenti = messaggioClient.split(" ", 2);

                    // Assegnazione dei frammenti alle relative locazioni di memoria
                    corpoMessaggio = messaggioClientFrammenti[1];

                    // Invio della risposta a tutti i client connessi alla rete di comunicazione
                    for (ClientHandler c : listaClient) {
                        if (!c.getNickname().equals(nickname)) {
                            messaggioServerOut = new PrintWriter(c.getClientSocket().getOutputStream(), true);
                            messaggioServerOut.println(nickname + ": " + corpoMessaggio);
                        }
                    }

                    // Riconnessione al client mittente
                    messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);
                    messaggioServerOut.println("App: Messaggio inviato!");

                // Cambio nickname
                } else if (messaggioClient.contains("NICK ")) {

                    // Dichiarazione ed implementazione variabili (locali)
                    String vecchioNickname;

                    // Implementazione variabili (locali)
                    i = 0;
                    isEsistente = false;

                    // Frammentazione di messaggioClient in due frammenti, dei quali si utilizza l'ultimo: nickname
                    messaggioClientFrammenti = messaggioClient.split(" ", 2);

                    // Verifica dell'esistenza del nickname impostato dal client
                    while (!isEsistente && i < listaClient.size()) {
                        client = listaClient.get(i);
                        if (client.getNickname().equals(messaggioClientFrammenti[1]))
                            isEsistente = true;
                        i++;
                    }

                    // Se il nickname non esiste già
                    if (!isEsistente) {
                        
                        // Implementazione di vecchioNickname
                        vecchioNickname = getNickname();

                        // Rimozione del vecchio client dalla lista di client connessi alla rete di comunicazione
                        listaClient.remove(this);
                        
                        // Inserimento del nuovo nickname
                        nickname = messaggioClientFrammenti[1];

                        // Aggiunta del nuovo client alla lista di client connessi alla rete di comunicazione
                        listaClient.add(this);

                        // Invio della risposta del server
                        messaggioServerOut.println("App: Modifica effettuata con successo!");

                        // Invio del messaggio di avvenuta modifica del nickname del client a tutti i client connessi alla rete di comunicazione
                        for (ClientHandler c : listaClient) {
                            if (!c.getNickname().equals(nickname)) {
                                messaggioServerOut = new PrintWriter(c.getClientSocket().getOutputStream(), true);
                                messaggioServerOut.println("App: " + vecchioNickname + " ha modificato il proprio nickname in " + nickname + '.');
                            }
                        }

                        // Riconnessione al client che ha modificato il proprio nome
                        messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);

                    // Altrimenti
                    } else {

                        // Inviare un messaggio di errore
                        messaggioServerOut.println("App: Attenzione! Utente già esistente.");
                    }

                // Lista di client connessi alla rete di comunicazione
                } else if (messaggioClient.equals("LIST")) {

                    // Invio della lista di nickname dei client connessi alla rete di comunicazione
                    messaggioServerOut.println(Arrays.toString(getListaClientNickname()));

                // "Disconnessione" del client dalla rete di comunicazione
                } else if (messaggioClient.equals("QUIT")) {

                    // Rimozione del client dalla lista di client connessi alla rete di comunicazione
                    listaClient.remove(this);

                    // Invio del messaggio di avvenuta "disconnessione" del client a tutti i client connessi alla rete di comunicazione
                    for (ClientHandler c : listaClient) {
                        if (!c.getNickname().equals(nickname)) {
                            messaggioServerOut = new PrintWriter(c.getClientSocket().getOutputStream(), true);
                            messaggioServerOut.println("App: " + nickname + " si è disconnesso.");
                        }
                    }

                    // Riconnessione al client "disconnesso" per permettere la disconnessione vera e propria
                    messaggioServerOut = new PrintWriter(clientSocket.getOutputStream(), true);

                // Errore
                } else {

                    // Invio di un messaggio di errore
                    messaggioServerOut.println("App: Attenzione! Seguire la seguente sintassi: <Modalità> [<Nickname>][<Corpo>].");
                }
            } while (!messaggioClient.equals("QUIT"));

            // Disconnessione vera e propria
            // Chiusura del socket di comunicazione
            clientSocket.close();
            // Chiusura dello stream dal client
            messaggioClientIn.close();
            // Chiusura dello stream verso il client
            messaggioServerOut.close();
        } catch (IOException e) {

            // Visualizzare un pop-up di errore (di I/O)
            showMessageDialog(null, "Sessione scaduta con l'host " + clientSocket.getInetAddress().getHostName() + '.', "Informazione", INFORMATION_MESSAGE);

            // Rimozione forzata del client dalla lista di client connessi alla rete di comunicazione
            listaClient.remove(this);
        }
    }
}
