/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 *
 * Developed by Giuseppe Carlino
 */
package chatlabserver;

import java.awt.Color; // Importare la classe Color
import java.awt.Image; // Importare la classe Image
import java.io.IOException; // Importare la classe IOException
import java.net.InetAddress; // Importare la classe InetAddress
import java.net.ServerSocket; // Importare la classe ServerSocket
import java.net.Socket; // Importare la classe Socket
import java.net.UnknownHostException; // Importare la classe UnknownHostException
import javax.swing.ImageIcon; // Importare la classe ImageIcon
import static javax.swing.JOptionPane.showMessageDialog; // Importare il metodo statico showMessageDialog dalla classe JOptionPane
import static javax.swing.JOptionPane.ERROR_MESSAGE; // Importare la costante ERROR_MESSAGE dalla classe JOptionPane

/**
 *
 * @author 39327
 */
public class ServerFrame extends javax.swing.JFrame {

    // Metodi costruttori
    public ServerFrame() {
        initComponents();
        
        // Dichiarazione ed implementazione oggetti (locali)
        Image icona = new ImageIcon(this.getClass().getResource("ct.png")).getImage();
        
        // Settaggio dell'icona di frame
        this.setIconImage(icona);
        
        // Impostare il colore nero come colore di sfondo del frame
        getContentPane().setBackground(Color.BLACK);        
        
        // Visualizzare a video il frame
        setVisible(true);
    }
    
    // Metodi setter
    public void setAreaOutputServer(String nuovoContenuto) {
        
        // Dichiarazione ed implementazione variabili (locali)
        String vecchioContenuto = areaOutputServer.getText();
            
        // Aggiornare il contenuto dell'area di visualizzazione dell'output
        areaOutputServer.setText(vecchioContenuto + nuovoContenuto);
    }

    // Altri metodi
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scorrimentoAreaOutputServer = new javax.swing.JScrollPane();
        areaOutputServer = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ChatLabServer");
        setBackground(new java.awt.Color(0, 0, 0));
        setResizable(false);

        areaOutputServer.setEditable(false);
        areaOutputServer.setBackground(new java.awt.Color(0, 0, 0));
        areaOutputServer.setColumns(20);
        areaOutputServer.setFont(new java.awt.Font("Courier New", 1, 13)); // NOI18N
        areaOutputServer.setForeground(new java.awt.Color(0, 255, 153));
        areaOutputServer.setRows(5);
        areaOutputServer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 153)));
        scorrimentoAreaOutputServer.setViewportView(areaOutputServer);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(scorrimentoAreaOutputServer, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 425, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(scorrimentoAreaOutputServer, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ServerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        // Dichiarazione variabili
        int porta = 12345;

        // Dichiarazione oggetti
        ServerFrame interfacciaGrafica = new ServerFrame();
        InetAddress indirizzo = null;

        // Impostazione dell'indirizzo IP dell'host
        try {
            indirizzo = InetAddress.getByName("192.168.153.1");
        } catch (UnknownHostException e) {

            // Visualizzare un pop up di errore (host sconosciuto)
            showMessageDialog(null, "Host sconosciuto: " + e.getMessage() + '.', "Errore", ERROR_MESSAGE);
        }

        // Verificare che la comunicazione client-server vada sempre a buon fine
        try (ServerSocket serverSocket = new ServerSocket(porta, 0, indirizzo)) {

            // Messaggio di conferma di ascolto (con IP dato) sulla porta indicata
            interfacciaGrafica.setAreaOutputServer("Server in ascolto su <" + indirizzo + ':' + porta + ">."); 

            // Concedere infinite richieste di connessione
            while (true) {

                // Accettazione di una richiesta di connessione
                Socket clientSocket = serverSocket.accept();

                // Messaggio di conferma di avvenuta connessione
                interfacciaGrafica.setAreaOutputServer("\nConnessione accettata da " + clientSocket.getInetAddress() + ".\n");

                // Avviare la comunicazione
                ClientHandler client = new ClientHandler(interfacciaGrafica, clientSocket);
                client.start();
            }
        } catch (IOException e) {
            
            // Se la porta è già occupata da un altro server
            if (e.getMessage().equals("Address already in use: bind"))
                
                // Visualizzare un pop-up di errore (di I/O)
                showMessageDialog(null, "Porta già occupata.", "Errore", ERROR_MESSAGE);
                
            
            // Chiudere il frame interfacciaGrafica
            interfacciaGrafica.dispose();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutputServer;
    private javax.swing.JScrollPane scorrimentoAreaOutputServer;
    // End of variables declaration//GEN-END:variables
}